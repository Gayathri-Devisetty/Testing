package com.virtusa.testing.test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TestGetTitle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriverManager.firefoxdriver().setup();
		String url="http://Google.com";
		WebDriver driver=new FirefoxDriver();
		driver.get(url);
		//driver.findElement(By.id("lst-ib")).sendKeys("Automation Testing");
		driver.findElement(By.linkText("Google Search")).sendKeys("Automation");
		


	}

}
