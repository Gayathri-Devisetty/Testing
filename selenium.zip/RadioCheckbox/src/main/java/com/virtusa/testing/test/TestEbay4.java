package com.virtusa.testing.test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TestEbay4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriverManager .firefoxdriver().setup(); //loading chrome driver from binary file
        String url="https://ebay.in"; //string url
        WebDriver driver=new FirefoxDriver(); //creating a driver of type web
        driver.get(url);
        driver.findElement(By.linkText("register")).click();
        driver.findElement(By.id("firstname")).sendKeys("gayathri"); // finding element by name
        driver.findElement(By.id("lastname")).sendKeys("devisetty");   //finding element by id
        driver.findElement(By.name("email")).sendKeys("gayu@gmail.com");
        driver.findElement(By.name("PASSWORD")).sendKeys("gayathri@g3");
        driver.findElement(By.linkText("Create account")).click();
		/*
		 * String name=driver.findElement(By.xpath("//div[@class='partialRegForm']")).
		 * getAttribute("firstname"); System.out.println(name);
		 */
        

	}

}
