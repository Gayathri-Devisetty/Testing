package com.virtusa.testing.test;

import org.openqa.selenium.By;
import org.openqa.selenium.By.ByName;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class RadioCheck {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriverManager.firefoxdriver().setup();
		String url="https://destinationqa.com/aut/RadioButtons.html";
		WebDriver driver=new FirefoxDriver();
		driver.get(url);
		driver.findElement(By.xpath("//input[@value='Mon']")).click();//selects the Monday radio button
		driver.findElement(By.xpath("//input[@name='orange']")).click();//checks the Orange CheckBox 
		//driver.findElement(By.xpath("//input[@name='red']")).clear();

	}

}
