package com.virtusa.testing.test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TestRediff {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriverManager.firefoxdriver().setup();
		String url="https://Rediff.com";
		WebDriver driver=new FirefoxDriver();
		driver.get(url);
		System.out.println(driver.getTitle());// prints the title of the page
		driver.findElement(By.linkText("Sign in")).click();
		System.out.println(driver.getTitle());
		driver.navigate().back();
		System.out.println(driver.getTitle());
		driver.navigate().forward();
		System.out.println(driver.getTitle());
		driver.close();
		

	}

}
