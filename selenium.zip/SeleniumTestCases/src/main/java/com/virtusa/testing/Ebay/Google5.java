package com.virtusa.testing.Ebay;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Google5 {

	public static void main(String[] args) {
		WebDriverManager.chromedriver().setup();
		String url="https://Google.co.in";
		WebDriver driver=new ChromeDriver();
		driver.get(url);
		driver.findElement(By.name("q")).sendKeys("Automation Testing tutorials");
		//driver.findElement(By.xpath("//input[@value='Google Search']")).click();
		driver.findElement(By.name("btnK")).submit();
		 WebDriverWait wait = new WebDriverWait(driver, 5);
		  wait.until(ExpectedConditions.titleContains("Automation Testing"));
		  String title="Automation Testing";
		 if(driver.getTitle().contains(title))
			 System.out.println("same content");
		
	}

}