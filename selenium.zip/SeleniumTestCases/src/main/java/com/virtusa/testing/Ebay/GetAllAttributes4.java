package com.virtusa.testing.Ebay;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class GetAllAttributes4 {

	public static void main(String[] args) {
		WebDriverManager .chromedriver().setup(); //loading chrome driver from binary file
        String baseurl="https://ebay.in"; //string url
        WebDriver driver=new ChromeDriver(); //creating a driver of type web
        driver.get(baseurl); //opening base url in browser
        System.out.println(driver.findElement(By.linkText("register")).getAttribute("href"));
        System.out.println(driver.findElement(By.linkText("register")).getAttribute("_sp"));

	}

}
