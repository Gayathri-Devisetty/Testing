package com.virtusa.testing.Ebay;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Autosuggest10 {

	public static void main(String[] args) {
		WebDriverManager.chromedriver().setup();
		String url="https://Google.co.in";
		WebDriver driver=new ChromeDriver();
		driver.get(url);
		 By.xpath("//input[@type='text']");
		driver.findElement(By.name("q")).sendKeys("Testing");
		List<WebElement> listGoogle = driver.findElement(By.xpath("//ul[@role='listbox']"))
		        .findElements(By.xpath("//li[@role='presentation']"));
		        for (int i = 0; i < listGoogle.size(); i++) {
		            System.out.println(listGoogle.get(i).getText());
		        }
	


	}

}
