package com.virtusa.testing.Ebay;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class RadioCheckBox2 {

	public static void main(String[] args) {
				WebDriverManager.firefoxdriver().setup();
				String url="https://destinationqa.com/aut/RadioButtons.html";
				WebDriver driver=new FirefoxDriver();
				driver.get(url);
				driver.findElement(By.xpath("//input[@value='Mon']")).click();//selects the Monday radio button
				driver.findElement(By.xpath("//input[@name='orange']")).click();//checks the Orange CheckBox 
				driver.findElement(By.xpath("//input[@name='red']")).click();
	}
}

	
