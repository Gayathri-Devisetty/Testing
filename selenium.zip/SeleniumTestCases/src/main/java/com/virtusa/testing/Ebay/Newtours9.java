package com.virtusa.testing.Ebay;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Newtours9 {

	public static void main(String[] args) {
		WebDriverManager.chromedriver().setup();
		String url="http://newtours.demoaut.com/";
		WebDriver driver=new ChromeDriver();
		driver.get(url);
		int nameht= driver.findElement(By.name("userName")).getSize().height;
		int namewd= driver.findElement(By.name("userName")).getSize().width;
		
		int paswordht= driver.findElement(By.name("password")).getSize().height;
		int passwordwd= driver.findElement(By.name("password")).getSize().width;
		
		if(nameht==paswordht)
			System.out.println("Same Height");
		else
			System.out.println("Different Height");
		
		if (passwordwd==namewd)
			System.out.println("Same Width");
		else
			System.out.println("Different Width");

	}

}
