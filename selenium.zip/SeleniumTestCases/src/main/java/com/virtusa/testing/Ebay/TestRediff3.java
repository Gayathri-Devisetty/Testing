package com.virtusa.testing.Ebay;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TestRediff3 {

	public static void main(String[] args) {
		    WebDriverManager.firefoxdriver().setup();
			String url="https://Rediff.com";
			WebDriver driver=new FirefoxDriver();
			driver.get(url);
			String hometitle=driver.getTitle();// prints the title of the page
			driver.findElement(By.linkText("Sign in")).click();
			String signtitle=driver.getTitle();
			driver.navigate().back();
			if(driver.getTitle().equals(hometitle))
				System.out.println("Equal Home Title");
			driver.navigate().forward();
			if(driver.getTitle().equals(signtitle))
				System.out.println("Sign in Tile Equal");
			driver.close();
	}

}
