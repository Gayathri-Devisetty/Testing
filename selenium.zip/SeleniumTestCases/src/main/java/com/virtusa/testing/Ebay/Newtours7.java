package com.virtusa.testing.Ebay;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Newtours7 {

	public static void main(String[] args) {
		WebDriverManager.chromedriver().setup();
		String url="http://newtours.demoaut.com/";
		WebDriver driver=new ChromeDriver();
		driver.get(url);
		driver.findElement(By.name("userName")).sendKeys("mercury");
		driver.findElement(By.name("password")).sendKeys("mercury");
		driver.findElement(By.name("login")).click();
		new Select(driver.findElement(By.xpath("//select[@name='passCount']"))).selectByIndex(3);
		new Select(driver.findElement(By.xpath("//select[@name='fromPort']"))).selectByValue("Paris");
		new Select(driver.findElement(By.xpath("//select[@name='fromMonth']"))).selectByValue("7");
		new Select(driver.findElement(By.xpath("//select[@name='fromDay']"))).selectByValue("24");
		
		new Select(driver.findElement(By.xpath("//select[@name='toPort']"))).selectByVisibleText("San Francisco");
		new Select(driver.findElement(By.xpath("//select[@name='toMonth']"))).selectByValue("12");
		new Select(driver.findElement(By.xpath("//select[@name='toDay']"))).selectByVisibleText("10");
		
		driver.findElement(By.name("findFlights")).click();

	}

}
