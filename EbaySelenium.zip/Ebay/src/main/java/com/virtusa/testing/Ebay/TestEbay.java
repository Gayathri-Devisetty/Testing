package com.virtusa.testing.Ebay;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TestEbay {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriverManager .chromedriver().setup(); //loading chrome driver from binary file
        String baseurl="https://ebay.in"; //string url
        WebDriver driver=new ChromeDriver(); //creating a driver of type web
        driver.get(baseurl); //opening base url in browser
        driver.findElement(By.linkText("register")).click(); //clicking on register link
        driver.findElement(By.name("firstname")).sendKeys("nitish"); // finding element by name
        driver.findElement(By.id("lastname")).sendKeys("kumar");   //finding element by id
        driver.findElement(By.name("email")).sendKeys("nitish@gmail.com");
        driver.findElement(By.name("PASSWORD")).sendKeys("Nitish@123");
        driver.findElement(By.linkText("Create account")).click(); //clicking on create account button

	}

}
